O diretório caminho é:
/home/millas/.config/Code/User